package com.example.tiktokresearch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    Spinner spinnerMonth, spinnerDay, spinnerYear;
    EditText editUsername, editPassword;
    RadioGroup genderGroup;
    Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinnerMonth = findViewById(R.id.spinnerMonth);
        spinnerDay = findViewById(R.id.spinnerDay);
        spinnerYear = findViewById(R.id.spinnerYear);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        genderGroup = findViewById(R.id.genderGroup);
        btnSignUp = findViewById(R.id.btnSignUp);

        // Month Spinner
        String[] months = {"Month", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        ArrayAdapter<String> monthAdapter = createCustomSpinnerAdapter(months);
        spinnerMonth.setAdapter(monthAdapter);
        spinnerMonth.setSelection(0);

        // Day Spinner
        String[] days = new String[32];
        days[0] = "Day";
        for (int i = 1; i <= 31; i++) {
            days[i] = String.valueOf(i);
        }
        ArrayAdapter<String> dayAdapter = createCustomSpinnerAdapter(days);
        spinnerDay.setAdapter(dayAdapter);
        spinnerDay.setSelection(0);

        // Year Spinner
        List<String> years = new ArrayList<>();
        years.add("Year");
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear; i >= 1900; i--) {
            years.add(String.valueOf(i));
        }
        ArrayAdapter<String> yearAdapter = createCustomSpinnerAdapter(years.toArray(new String[0]));
        spinnerYear.setAdapter(yearAdapter);
        spinnerYear.setSelection(0);

        btnSignUp.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();
            int selectedGenderId = genderGroup.getCheckedRadioButtonId();

            boolean isDateIncomplete = spinnerMonth.getSelectedItemPosition() == 0 ||
                    spinnerDay.getSelectedItemPosition() == 0 ||
                    spinnerYear.getSelectedItemPosition() == 0;

            if (username.isEmpty() || password.isEmpty() || selectedGenderId == -1 || isDateIncomplete) {
                Toast.makeText(MainActivity2.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
            } else {
                int year = Integer.parseInt(spinnerYear.getSelectedItem().toString());
                int month = spinnerMonth.getSelectedItemPosition(); // 1-based
                int day = Integer.parseInt(spinnerDay.getSelectedItem().toString());

                Calendar today = Calendar.getInstance();
                Calendar birthDate = Calendar.getInstance();
                birthDate.set(year, month - 1, day);

                int age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);
                if (today.get(Calendar.DAY_OF_YEAR) < birthDate.get(Calendar.DAY_OF_YEAR)) {
                    age--;
                }

                if (age < 18) {
                    Toast.makeText(MainActivity2.this, "You must be at least 18 years old to sign up.", Toast.LENGTH_LONG).show();
                } else {
                    // Save user credentials (optional)
                    SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("username", username);
                    editor.putString("password", password);
                    editor.apply();

                    // Send birthdate and username to MainActivity4
                    Intent intent = new Intent(MainActivity2.this, MainActivity4.class);
                    intent.putExtra("username", username);
                    intent.putExtra("birthYear", year);
                    intent.putExtra("birthMonth", month);
                    intent.putExtra("birthDay", day);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    private ArrayAdapter<String> createCustomSpinnerAdapter(String[] items) {
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public boolean isEnabled(int position) {
                return position != 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.parseColor("#CCCCCC"));
                view.setBackgroundColor(Color.parseColor("#1A1A1A"));
                view.setTypeface(ResourcesCompat.getFont(getApplicationContext(), R.font.proxima_nova_semibold));
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Color.parseColor("#CCCCCC"));
                view.setBackgroundColor(Color.parseColor("#1A1A1A"));
                view.setTypeface(ResourcesCompat.getFont(getApplicationContext(), R.font.proxima_nova_semibold));
                return view;
            }
        };
    }
}
