package com.example.tiktokresearch;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        TextView welcomeText = findViewById(R.id.welcomeText);
        Button watchVideosButton = findViewById(R.id.button3); // Make sure this ID matches your layout

        String username = getIntent().getStringExtra("username");

        if (username != null && !username.isEmpty()) {
            welcomeText.setText("Welcome to TikTalkTruth, " + username + "!");
        } else {
            welcomeText.setText("Welcome!");
        }

        // ✅ Corrected: Open MainActivity5, not MainActivity
        watchVideosButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
            startActivity(intent);
        });
    }
}
