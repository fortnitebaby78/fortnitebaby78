package com.example.tiktokresearch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button btnSignUp; // This is actually your login button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnSignUp = findViewById(R.id.btnSignUp);

        btnSignUp.setOnClickListener(v -> {
            String enteredUsername = editUsername.getText().toString().trim();
            String enteredPassword = editPassword.getText().toString().trim();

            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String savedUsername = sharedPreferences.getString("username", null);
            String savedPassword = sharedPreferences.getString("password", null);

            if (enteredUsername.equals(savedUsername) && enteredPassword.equals(savedPassword)) {
                Toast.makeText(MainActivity3.this, "Welcome back, " + enteredUsername + "!", Toast.LENGTH_SHORT).show();

                // Proceed to MainActivity4 after successful login
                Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity3.this, "Invalid username or password!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
